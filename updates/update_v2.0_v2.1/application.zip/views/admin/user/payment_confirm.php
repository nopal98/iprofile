<div class="content-wrapper">
  <!-- Main content -->
  <section class="content">
    <div class="container mt-300 mb-20">
        <div class="text-center m-auto col-md-6">
            <div class="pay_status p-20">
              <strong><i class="fa fa-question-circle"></i> Are you sure want to upgrade your plan?</strong>
            </div><br><br>
            <a class="btn btn-primary" href="<?php echo base_url('admin/subscription/upgrade/'.$slug.'/'.$billing_type.'/1') ?>">Yes Continue <i class="fa fa-long-arrow-right"></i></a>
        </div>
    </div>
  </section>
</div>