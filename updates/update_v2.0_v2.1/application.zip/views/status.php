

  <section class="section-padding">
      <div class="container">

          <div class="row minh-400">
              <div class="space-60"></div>
              <div class="col-md-6 col-md-offset-3">
                  <div class="page-title">
                    <h2 class="text-danger"><i class="fa fa-exclamation-circle fa-2x" aria-hidden="true"></i></h2>
                      <div class="space-60"></div>
                      <h2 class="title text-warning">Profile is not available</h2>
                      <div class="space-60"></div>
                  </div>
              </div>

          </div>

      </div>
  </section>