
</div>
</main>
<!-- Main Wrapper end -->

<!-- Javascripts
================================================== -->  
<script src="<?php echo base_url() ?>assets/default/js/jquery-2.1.4.min.js"></script> 
<script src="<?php echo base_url() ?>assets/default/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>assets/default/js/owl.carousel.min.js"></script> 
<!-- for color alternatives -->
<script src="<?php echo base_url() ?>assets/default/js/moment.js"></script>
<script src="<?php echo base_url() ?>assets/default/js/jquery.cookie-1.4.1.min.js"></script>
<script src="<?php echo base_url() ?>assets/default/datetime/datetimepicker.js"></script>


<script src="<?php echo base_url() ?>assets/default/js/aos.js"></script>
<script src="<?php echo base_url() ?>assets/default/js/custom5.js"></script>
<script src="<?php echo base_url() ?>assets/default/js/jquery.filterizr.js"></script>


<script type="text/javascript">
	$(document).ready(function(){
		AOS.init();
	  $('[data-toggle="tooltip"]').tooltip(); 
	});
    
  $(function () {
      $('.datetimepicker1').datetimepicker({
         format:'YYYY-MM-DD HH:mm:ss',
      });
  });

</script>



</body>

</html>
